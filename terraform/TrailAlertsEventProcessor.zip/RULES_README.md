# Configuration Rules

This directory contains configuration rules that are used to enhance the processing of Sigma rules. These are not Sigma rules themselves, but rather configuration files that define how certain Sigma rules should be processed.

## Rule Types

### Threshold Rules

Threshold rules are used to detect patterns of activity that may not be suspicious individually but become suspicious when repeated. For example, a single access to a secret might be normal, but multiple accesses in a short time window could indicate an attack.

Example threshold rule:
```json
{
  "type": "threshold",
  "sigmaRuleTitle": "AWS SecretsManager GetSecretValue",
  "thresholdCount": 10,
  "windowMinutes": 5,
  "ttlSeconds": 300,
  "severity_adjustment": "medium",
  "description": "Multiple SecretsManager accesses by same actor in short time window"
}
```

### Correlation Rules

Correlation rules are used to detect related events that together indicate a higher risk. For example, a user creation followed by a policy attachment might indicate an attempt to create a privileged user.

Example correlation rule:
```json
{
  "type": "correlation",
  "sigmaRuleTitle": "AWS CloudTrail Attach Policy",
  "lookFor": "AWS CloudTrail IAM User Creation",
  "windowMinutes": 15,
  "severity_adjustment": "high",
  "description": "Role creation followed by policy attachment"
}
```

## How Rules Are Used

The Sigma Event Processor looks up the title of each Sigma rule in these configuration rules. If a match is found, the event is processed according to the rule type:

1. For threshold rules, the event is counted and only triggers a notification when the threshold is exceeded.
2. For correlation rules, the event is checked against previous events to find correlations.

## Rule Storage

Rules should be stored in the S3 bucket specified by `CORRELATION_RULES_BUCKET` in the following structure:

- `postprocessing_rules/`: Directory for all post-processing configuration rules

Each rule file should be a JSON file containing a single rule or an array of rules. The rules can be organized in any way you prefer, as the system will filter them based on the `type` field:

- Rules with `"type": "threshold"` will be processed by the threshold engine
- Rules with `"type": "correlation"` will be processed by the correlation engine

You can create multiple JSON files with different naming conventions to organize your rules logically, for example:
- `postprocessing_rules/aws_security_rules.json`
- `postprocessing_rules/azure_security_rules.json`
- `postprocessing_rules/custom_rules.json`

## Note on Sigma Rules

The original Sigma rules should be stored separately from these post-processing rules. The post-processing rules are only used to enhance the processing of events that match Sigma rules. 