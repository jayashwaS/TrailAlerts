# Sigma Event Processor

This Lambda function processes CloudTrail events matched by Sigma rules and handles different types of event processing:

1. **Regular Events**: Standard processing of CloudTrail events matched by Sigma rules
2. **Correlation Events**: Events that are correlated with other events based on defined rules
3. **Threshold Events**: Events that are counted and only trigger notifications when a threshold is exceeded

## Event Types

The system determines the event type by checking if there are matching rules in the correlation or threshold collections. The Sigma rules themselves don't have a "type" field - instead, the system looks up the rule title in the appropriate collections.

### Regular Events

Regular events are processed as-is and stored in DynamoDB with a standard TTL of 30 days. These are events that don't match any correlation or threshold rules.

### Correlation Events

Correlation events are processed to find related events based on defined correlation rules. When a correlation is found, the severity is adjusted and a notification is sent.

Example correlation rule:
```json
{
  "type": "correlation",
  "sigmaRuleTitle": "AWS CloudTrail Attach Policy",
  "lookFor": "AWS CloudTrail IAM User Creation",
  "windowMinutes": 15,
  "severity_adjustment": "high",
  "description": "Role creation followed by policy attachment"
}
```

### Threshold Events

Threshold events are processed when a rule is triggered multiple times by the same actor within a specified time window. The system:

1. Determines if a rule is a threshold rule by checking if there's a matching rule in the threshold collection
2. Stores the event in DynamoDB with a short TTL (configurable, default 5 minutes)
3. Checks if the threshold is exceeded by querying for similar events
4. If the threshold is exceeded, adjusts the severity and stores the event as a regular event
5. Applies a configurable cooldown period to prevent notification fatigue

### Threshold Rule Configuration

Threshold rules are stored in the `postprocessing_rules/` directory in the S3 bucket. Each rule has the following format:

```json
{
  "type": "threshold",
  "sigmaRuleTitle": "Rule Title",
  "thresholdCount": 5,
  "windowMinutes": 10,
  "ttlSeconds": 3600,
  "severity_adjustment": "high",
  "description": "Description of the threshold rule",
  "cooldownMinutes": 60
}
```

- `type`: Must be "threshold"
- `sigmaRuleTitle`: The title of the Sigma rule to match
- `thresholdCount`: The number of events required to exceed the threshold
- `windowMinutes`: The time window in minutes to check for threshold
- `ttlSeconds`: The TTL for threshold events in seconds
- `severity_adjustment`: The severity to set when threshold is exceeded
- `description`: A description of the threshold rule
- `cooldownMinutes`: The cooldown period in minutes between notifications (default: 60)

### Rule Exceptions

The system supports a centralized exceptions mechanism to exclude specific events from processing based on various criteria. Exceptions are defined in an `exceptions.json` file stored in the root of the S3 bucket.

Example exceptions configuration:
```json
{
  "AWS SecretsManager GetSecretValue": {
    "excludedActors": [
      "arn:aws:iam::123456789012:user/ci-bot",
      "arn:aws:iam::123456789012:role/app-sync"
    ],
    "excludedSourceIPs": [
      "10.0.1.100"
    ],
    "excludedActorsRegex": [
      "^arn:aws:iam::123456789012:role/dev-.*"
    ]
  },
  "AWS Console Login": {
    "excludedActors": [
      "arn:aws:iam::123456789012:user/monitoring"
    ]
  }
}
```

The exceptions configuration supports the following criteria:
- `excludedActors`: List of IAM user/role ARNs to exclude
- `excludedSourceIPs`: List of source IP addresses to exclude
- `excludedActorsRegex`: List of regex patterns to match against actor ARNs

When an event matches any of the exclusion criteria for its rule, it will be skipped entirely and no notification will be sent.

### Notification Cooldown

To prevent notification fatigue, the system implements a configurable cooldown period for each rule. When a notification is sent for a rule, the system:

1. Records the notification time in DynamoDB
2. Checks the cooldown period before sending subsequent notifications
3. Only sends a new notification if the cooldown period has elapsed

The cooldown period can be configured in two ways:

1. **Global Cooldown**: A global setting in Terraform that applies to all rules by default
2. **Rule-Specific Cooldown**: Individual cooldown periods specified in threshold rules

For threshold rules, if a rule-specific cooldown is specified, it will override the global cooldown. For correlation and regular events, the global cooldown is always used.

## Configuration

The Lambda function requires the following environment variables:

- `DYNAMODB_TABLE_NAME`: The name of the DynamoDB table for storing events
- `SOURCE_EMAIL`: The source email address for SES notifications
- `EMAIL_RECIPIENT`: The destination email address for notifications

Optional environment variables:

- `VPNAPI_KEY`: API key for VPN service (for IP information)
- `SNS_TOPIC_ARN`: SNS topic ARN for notifications
- `CORRELATION_RULES_BUCKET`: S3 bucket containing correlation and threshold rules
- `CORRELATION_ENABLED`: Boolean to enable correlation and threshold processing
- `NOTIFICATION_COOLDOWN_MINUTES`: Global cooldown period in minutes between notifications (default: 60)
- `MIN_NOTIFICATION_SEVERITY`: Minimum severity level for sending notifications (default: medium)

## Rule Configuration

Rules should be stored in the S3 bucket specified by `CORRELATION_RULES_BUCKET` in the following structure:

- `correlation/`: Directory for correlation rules
- `threshold/`: Directory for threshold rules

Each rule file should be a JSON file containing a single rule or an array of rules.

## DynamoDB Schema

The DynamoDB table uses the following schema:

- `pk`: Partition key (EVENT, THRESHOLD#{rule_title}#{actor}, or CORRELATION#{actor})
- `sk`: Sort key (timestamp#uuid)
- `sigmaRuleTitle`: The title of the Sigma rule
- `timestamp`: The timestamp of the event
- `actor`: The actor (ARN) that performed the action
- `eventType`: The type of event (regular, threshold, correlation)
- Other event attributes (sourceType, eventName, target, accountId, severity, etc.)

## Indexes

The DynamoDB table includes the following indexes:

- `sigmaRuleTitleIndex`: For querying by sigmaRuleTitle and timestamp
- `actorIndex`: For querying by actor and timestamp
- `eventTypeIndex`: For querying by eventType and timestamp 