"""
Sigma Event Processor

A Lambda function for processing security events and sending notifications.
""" 