from typing import Any, Dict, List

def get_nested_value(dict_obj: Dict[str, Any], key_list: List[str]) -> Any:
    """
    Retrieves a nested value from a dictionary based on a list of keys.
    
    Args:
        dict_obj: The dictionary to search
        key_list: List of keys to traverse
        
    Returns:
        Any: The value at the nested location or empty dict if not found
    """
    for key in key_list:
        dict_obj = dict_obj.get(key, {})
    return dict_obj